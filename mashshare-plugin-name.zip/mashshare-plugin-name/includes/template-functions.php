<?php

/**
 * Template Functions
 *
 * @package     MASHSB\PluginName
 * @subpackage  Functions/Templates
 * @copyright   @todo
 * @license     http://opensource.org/licenses/gpl-2.0.php GNU Public License
 * @since       1.0.0
 */


// Exit if accessed directly
if( !defined( 'ABSPATH' ) ) exit;

